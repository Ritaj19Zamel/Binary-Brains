# Graph Neural Network

For Graph Neural Network.

## Instructions

1. Install:

```
pip install Graph-Package
```
