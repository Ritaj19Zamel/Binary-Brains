# package_for_math
This package contain a mathimatical functions
