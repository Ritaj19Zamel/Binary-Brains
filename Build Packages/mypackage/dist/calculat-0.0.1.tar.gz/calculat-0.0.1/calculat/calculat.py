def SumTwoNum(x,y):
    return x+y