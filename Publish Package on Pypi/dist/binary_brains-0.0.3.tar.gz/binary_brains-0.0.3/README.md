# binary-brains
### to install:
```bash
pip3 install binary-brains
```
