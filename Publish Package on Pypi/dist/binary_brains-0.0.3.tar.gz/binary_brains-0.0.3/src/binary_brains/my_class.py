class MyClass:
	def my_test_func(self):
		return "test function"
